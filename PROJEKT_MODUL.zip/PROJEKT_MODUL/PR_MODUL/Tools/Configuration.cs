

namespace PR_MODUL
{
    using System;
    using System.Drawing;
    using System.IO;
    using System.Xml;
    using System.Text;
    using System.Windows.Forms;

    /// <summary>
    /// Application configuration
    /// </summary>
    public class Configuration
    {
        public Point mainWindowLocation = new Point( 100, 50 );
        public Size mainWindowSize = new Size( 800, 600 );

        public bool histogramVisible = false;
        public bool statisticsVisible = false;

        public bool openInNewDoc = false;
        public bool rememberOnChange = false;

    }
}
